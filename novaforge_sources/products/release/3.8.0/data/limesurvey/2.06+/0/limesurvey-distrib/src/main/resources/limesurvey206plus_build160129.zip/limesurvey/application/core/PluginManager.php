<?php

/**
 * Class PluginManagerD
 * Dummy class for 2.05 plugins.
 */
class PluginManager extends CApplicationComponent
{

}