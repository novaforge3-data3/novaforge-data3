<?php

class PluginEvent extends \ls\pluginmanager\PluginEvent 
{
    
}
